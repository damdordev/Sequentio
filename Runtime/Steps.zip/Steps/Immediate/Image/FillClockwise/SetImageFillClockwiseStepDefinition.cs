using System;
using UnityEngine.UI;

namespace Damdor.Sequentio
{
    /// <summary>
    /// Defines a step for setting whether an image fills clockwise.
    /// </summary>
    [Serializable]
    [SequentioStep(typeof(SetImageFillClockwiseStepPlayer), "Image/FillClockwise", "Fill Clockwise", "Packages/com.damdor.sequentio/Editor/StepsIcons/position.png")]
    public class SetImageFillClockwiseStepDefinition : ValueImmediateStepDefinition<Image, bool>
    {
    }
}
